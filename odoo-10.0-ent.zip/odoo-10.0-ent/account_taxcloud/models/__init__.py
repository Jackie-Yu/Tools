# -*- coding: utf-8 -*-

import account_fiscal_position
import account_invoice
import product
import res_config
