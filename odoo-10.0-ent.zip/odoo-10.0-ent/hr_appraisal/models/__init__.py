# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import calendar_event
import hr_appraisal
import hr_employee
import hr_department
import survey
