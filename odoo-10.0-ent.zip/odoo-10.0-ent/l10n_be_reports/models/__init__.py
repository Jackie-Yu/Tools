# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import account_financial_report_xml_export
import partner_vat_listing
import partner_vat_intra
