# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import revenue_kpis_dashboard
import salesman_dashboard
import stat_types
