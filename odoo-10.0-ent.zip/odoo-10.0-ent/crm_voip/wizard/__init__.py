# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import crm_phonecall_log_wizard
import crm_phonecall_schedule_wizard
import crm_phonecall_transfer_wizard
