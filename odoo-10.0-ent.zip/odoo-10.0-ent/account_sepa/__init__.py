# -*- coding: utf-8 -*-

import res_company
import res_config
import account_journal
import account_journal_dashboard
import account_payment
import sepa_credit_transfer
